from transformers import pipeline

# Example: English to Hindi model
model_name = 'Helsinki-NLP/opus-mt-en-hi'
translator = pipeline('translation', model=model_name)

def translate_text(text, target_lang='hi'):
    if not text:
        return ''
    out = translator(text, max_length=128)
    return out[0]['translation_text']

if __name__ == '__main__':
    print(translate_text('HELLO'))
