import os
import numpy as np
from glob import glob
from sklearn.preprocessing import LabelEncoder

RAW_DIR = 'dataset/raw'
OUT_DIR = 'dataset/processed'
os.makedirs(OUT_DIR, exist_ok=True)

SEQUENCE_LENGTH = 30  # frames per sample
STEP = 15  # sliding window step

files = glob(os.path.join(RAW_DIR, '*.npz'))
data = []
labels = []

for f in files:
    name = os.path.basename(f)
    label = name.split('_')[0]
    arr = np.load(f)['landmarks']  # shape (T, 126)
    T = arr.shape[0]
    if T < 5:
        continue
    for start in range(0, max(1, T - SEQUENCE_LENGTH + 1), STEP):
        block = arr[start:start + SEQUENCE_LENGTH]
        if block.shape[0] < SEQUENCE_LENGTH:
            pad = np.zeros((SEQUENCE_LENGTH - block.shape[0], block.shape[1]), dtype=block.dtype)
            block = np.vstack([block, pad])
        data.append(block)
        labels.append(label)

X = np.array(data)  # (N, SEQ, D)
le = LabelEncoder()
y = le.fit_transform(labels)
np.savez_compressed(os.path.join(OUT_DIR, 'dataset.npz'), X=X, y=y, classes=le.classes_)
print('Saved processed dataset:', os.path.join(OUT_DIR, 'dataset.npz'))
print('Classes:', list(le.classes_))
