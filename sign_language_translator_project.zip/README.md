# AI Sign Language Translator - Project ZIP

Files included:
- recorder.py            # Record webcam video and save mediapipe landmarks per recording
- preprocess.py         # Build a dataset with sliding windows from recorded landmarks
- train_lstm.py         # Train an LSTM classifier
- translate.py          # Uses HuggingFace MarianMT to translate gloss -> target language
- infer_realtime.py     # Real-time webcam inference and overlay translation
- deploy_api.py         # FastAPI server to accept sequences of landmarks and return prediction
- simple_frontend.html  # Minimal demo HTML (placeholder)
- requirements.txt      # Python dependencies

Quick start:
1. Create and activate a virtual environment.
2. pip install -r requirements.txt
3. Run recorder.py to record labeled samples (press 'r' to start/stop).
4. Run preprocess.py to build dataset.
5. Run train_lstm.py to train the model (saved to models/).
6. Run infer_realtime.py to test live predictions.

Notes:
- This is an MVP isolated-sign pipeline. For continuous sign translation or production usage, expand dataset, add pose/face features, and consider privacy and performance optimizations.
