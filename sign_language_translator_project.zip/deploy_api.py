from fastapi import FastAPI
from pydantic import BaseModel
import numpy as np
import tensorflow as tf
from translate import translate_text

app = FastAPI()
MODEL_PATH = 'models/lstm_sign_classifier.h5'
model = tf.keras.models.load_model(MODEL_PATH)

class SeqIn(BaseModel):
    features: list  # list of frames, each frame is list[126]

@app.post('/predict')
async def predict(seq_in: SeqIn):
    arr = np.array(seq_in.features, dtype=np.float32)
    if arr.ndim != 2 or arr.shape[1] != 126:
        return {'error': 'features must be shape (T,126)'}
    SEQ_LEN = 30
    if arr.shape[0] < SEQ_LEN:
        pad = np.zeros((SEQ_LEN - arr.shape[0], 126), dtype=np.float32)
        arr = np.vstack([arr, pad])
    else:
        arr = arr[:SEQ_LEN]
    arr = arr - np.mean(arr, axis=1, keepdims=True)
    maxv = np.max(np.abs(arr))
    if maxv > 0:
        arr /= maxv
    pred = model.predict(arr[np.newaxis, ...])
    idx = int(np.argmax(pred, axis=1)[0])
    classes = np.load('dataset/processed/dataset.npz')['classes']
    gloss = classes[idx]
    translated = translate_text(gloss)
    return {'gloss': str(gloss), 'translation': translated}

# run: uvicorn deploy_api:app --reload --port 8000
