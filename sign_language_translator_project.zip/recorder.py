import cv2
import mediapipe as mp
import numpy as np
import time
import os
from datetime import datetime

OUT_DIR = "dataset/raw"
os.makedirs(OUT_DIR, exist_ok=True)

mp_hands = mp.solutions.hands
hands = mp_hands.Hands(static_image_mode=False, max_num_hands=2, min_detection_confidence=0.5)
mp_drawing = mp.solutions.drawing_utils

cap = cv2.VideoCapture(0)
print("Controls: r to start/stop recording, q to quit")
recording = False
writer = None
landmarks_buffer = []
label = input('Enter gloss/label for this recording session (e.g. HELLO): ').strip()

while True:
    ret, frame = cap.read()
    if not ret:
        break
    frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    res = hands.process(frame_rgb)

    if res.multi_hand_landmarks:
        for lm in res.multi_hand_landmarks:
            mp_drawing.draw_landmarks(frame, lm, mp_hands.HAND_CONNECTIONS)

    cv2.putText(frame, f"REC: {recording}", (10,30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0,0,255) if recording else (0,255,0), 2)
    cv2.imshow('Recorder', frame)

    key = cv2.waitKey(1) & 0xFF
    if key == ord('r'):
        # toggle recording
        recording = not recording
        if recording:
            tstamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            video_path = os.path.join(OUT_DIR, f"{label}_{tstamp}.mp4")
            npz_path = os.path.join(OUT_DIR, f"{label}_{tstamp}.npz")
            fourcc = cv2.VideoWriter_fourcc(*'mp4v')
            h, w = frame.shape[:2]
            writer = cv2.VideoWriter(video_path, fourcc, 20.0, (w,h))
            landmarks_buffer = []
            print('Started recording ->', video_path)
        else:
            # finish and save landmarks
            writer.release()
            np.savez_compressed(npz_path, landmarks=np.array(landmarks_buffer))
            print('Saved landmarks ->', npz_path)
            writer = None
    elif key == ord('q'):
        if recording and writer is not None:
            writer.release()
        break

    if recording and writer is not None:
        writer.write(frame)
        # extract landmarks vector per-frame
        feat = np.zeros(21*3*2, dtype=np.float32)
        if res.multi_hand_landmarks:
            # map by label
            hands_coords = {'Left': None, 'Right': None}
            for i, hand_landmarks in enumerate(res.multi_hand_landmarks):
                hlabel = res.multi_handedness[i].classification[0].label
                coords = []
                for lm in hand_landmarks.landmark:
                    coords.extend([lm.x, lm.y, lm.z])
                hands_coords[hlabel] = coords
            if hands_coords['Right'] is not None:
                feat[0:63] = hands_coords['Right'][:63]
            if hands_coords['Left'] is not None:
                feat[63:126] = hands_coords['Left'][:63]
        landmarks_buffer.append(feat)

cap.release()
cv2.destroyAllWindows()
