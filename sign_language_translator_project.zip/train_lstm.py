import numpy as np
import tensorflow as tf
from tensorflow.keras import layers, models
from sklearn.model_selection import train_test_split
import os

DATA_PATH = 'dataset/processed/dataset.npz'
model_out = 'models/lstm_sign_classifier.h5'
os.makedirs('models', exist_ok=True)

arr = np.load(DATA_PATH)
X = arr['X']
y = arr['y']
classes = arr['classes']

# minimal normalization per-sample
X = X.astype('float32')
X = X - np.mean(X, axis=1, keepdims=True)
maxv = np.max(np.abs(X))
if maxv > 0:
    X /= maxv

X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.15, random_state=42, stratify=y)

inp = layers.Input(shape=(X.shape[1], X.shape[2]))
x = layers.Masking(mask_value=0.0)(inp)
x = layers.Bidirectional(layers.LSTM(128, return_sequences=True))(x)
x = layers.Bidirectional(layers.LSTM(64))(x)
x = layers.Dense(128, activation='relu')(x)
x = layers.Dropout(0.4)(x)
out = layers.Dense(len(classes), activation='softmax')(x)
model = models.Model(inp, out)
model.compile(optimizer='adam', loss='sparse_categorical_crossentropy', metrics=['accuracy'])

callbacks = [
    tf.keras.callbacks.ModelCheckpoint(model_out, save_best_only=True, monitor='val_loss'),
    tf.keras.callbacks.EarlyStopping(patience=8, restore_best_weights=True)
]

history = model.fit(X_train, y_train, validation_data=(X_val, y_val), epochs=80, batch_size=32, callbacks=callbacks)
print('Saved model ->', model_out)
