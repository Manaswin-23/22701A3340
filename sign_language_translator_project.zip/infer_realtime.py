import cv2
import mediapipe as mp
import numpy as np
from collections import deque
import tensorflow as tf
from translate import translate_text

MODEL_PATH = 'models/lstm_sign_classifier.h5'
SEQ_LEN = 30
GLOSS_CLASSES_PATH = 'dataset/processed/dataset.npz'  # reuse saved classes

# load classes
import numpy as np
arr = np.load(GLOSS_CLASSES_PATH)
classes = arr['classes']

model = tf.keras.models.load_model(MODEL_PATH)

mp_hands = mp.solutions.hands
hands = mp_hands.Hands(static_image_mode=False, max_num_hands=2, min_detection_confidence=0.5)
mp_drawing = mp.solutions.drawing_utils

cap = cv2.VideoCapture(0)
seq = deque(maxlen=SEQ_LEN)
last_prediction = None
last_time = 0

while True:
    ret, frame = cap.read()
    if not ret:
        break
    image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    res = hands.process(image)
    image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)

    feat = np.zeros(21*3*2, dtype=np.float32)
    if res.multi_hand_landmarks:
        hands_coords = {'Left': None, 'Right': None}
        for i, hand_landmarks in enumerate(res.multi_hand_landmarks):
            hlabel = res.multi_handedness[i].classification[0].label
            coords = []
            for lm in hand_landmarks.landmark:
                coords.extend([lm.x, lm.y, lm.z])
            hands_coords[hlabel] = coords
            mp_drawing.draw_landmarks(image, hand_landmarks, mp_hands.HAND_CONNECTIONS)
        if hands_coords['Right'] is not None:
            feat[0:63] = hands_coords['Right'][:63]
        if hands_coords['Left'] is not None:
            feat[63:126] = hands_coords['Left'][:63]

    seq.append(feat)
    if len(seq) == SEQ_LEN:
        arr_seq = np.array(seq, dtype=np.float32)
        arr_seq = arr_seq - np.mean(arr_seq, axis=1, keepdims=True)
        maxv = np.max(np.abs(arr_seq))
        if maxv > 0:
            arr_seq /= maxv
        pred = model.predict(arr_seq[np.newaxis, ...])
        idx = int(np.argmax(pred, axis=1)[0])
        gloss = classes[idx]
        # only update translation every 1.0s to reduce API calls
        import time
        if time.time() - last_time > 1.0:
            translated = translate_text(gloss)
            last_prediction = (gloss, translated)
            last_time = time.time()

    if last_prediction is not None:
        gloss, translated = last_prediction
        cv2.putText(image, f"{gloss} -> {translated}", (10,40), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255,255,255), 2)

    cv2.imshow('Infer', image)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
